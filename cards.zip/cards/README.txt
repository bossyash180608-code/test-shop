HOW TO ADD A NEW SHOP
1. Copy the folder "sharma-cafe" and rename it to the new shop (example: glow-salon). Use lowercase and hyphens only.
2. Open glow-salon/index.html in any text editor.
3. Edit only the SHOP block near the bottom (name, tagline, googleReview, whatsapp, instagram, facebook, prompts).
4. Upload the folder to your GitHub repository.
5. Link for the card: https://YOURUSERNAME.github.io/REPONAME/glow-salon/
6. Test every button on Android and iPhone, then write the link to the NFC card.
